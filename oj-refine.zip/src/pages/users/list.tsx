import React from "react";
import {
    useDataGrid,
    EditButton,
    ShowButton,
    DeleteButton,
    List,
} from "@refinedev/mui";
import { DataGrid, GridColDef, GridColumns, GridToolbar, GridPagination, useGridApiContext, useGridSelector, gridPageCountSelector } from "@mui/x-data-grid";
import { IResourceComponentsProps, useTranslate } from "@refinedev/core";
import { useEffect, useMemo, useState } from 'react';


import MuiPagination from '@mui/material/Pagination';
import { TablePaginationProps } from '@mui/material/TablePagination';

export const UserList: React.FC<IResourceComponentsProps> = () => {

    const translate = useTranslate();
    const { dataGridProps } = useDataGrid({initialPageSize: 15});

    const {
        pageSize,
        rows,
        onPageSizeChange,
        onPageChange,
    } = dataGridProps;


    let data_grid = {};
    if(dataGridProps.rows){ data_grid = dataGridProps.rows; 
    }else{ dataGridProps.rows = {}}

    
    function Pagination({
        page,
        onPageChange,
        className,
      }: Pick<TablePaginationProps, 'page' | 'onPageChange' | 'className'>) {
        const apiRef = useGridApiContext();
        const pageCount = useGridSelector(apiRef, gridPageCountSelector);
      
        return (
          <MuiPagination
            color="primary"
            className={className}
            count={pageCount}
            page={page + 1}
            onChange={(event, newPage) => {
              onPageChange(event as any, newPage - 1);
            }}
          />
        );
      }
      
      function CustomPagination(props: any) {
        return <GridPagination ActionsComponent={Pagination} {...props} />;
      }

      console.log("DATA GRID PROPS:::"+ JSON.stringify(dataGridProps));

    const columns =  React.useMemo<GridColDef[]>(
        () => [
            {
                field: "id",
                headerName: translate("users.fields.id"),
                type: "number",
                minWidth: 50,
                width: 50,
                align: "left",
                headerAlign: "left",
            },
            {
                field: "image",
                headerName: translate("users.fields.image"),
                sortable: false,
                renderCell: function render({ row }) {
                    return (
                        <>
                            <img id={row._id} width="25" height="25" className="rounded-full" src={`http://localhost:5173/${row.image}`} />
                        </>
                    );
                },
                align: "center",
                headerAlign: "center",
                minWidth: 80,
            },
            {
                field: "username",
                headerName: translate("users.fields.username"),
                minWidth: 180,
                resizable:  true
            },
            {
                field: "firstName",
                flex: 1,
                headerName: translate("users.fields.firstName"),
                minWidth: 100,
                resizable:  true
            },
            {
                field: "lastName",
                flex: 1,
                headerName: translate("users.fields.lastName"),
                resizable:  true
            },
            {
                field: "email",
                flex: 1,
                headerName: translate("users.fields.email"),
                minWidth: 250,
                resizable:  true
            },
            {
                field: "wallet",
                flex: 1,
                headerName: translate("users.fields.wallet")
            },
            {
                field: "status",
                flex: 1,
                headerName: translate("users.fields.status")
            },
            {
                field: "actions",
                headerName: translate("table.actions"),
                sortable: false,
                renderCell: function render({ row }) {
                    return (
                        <>
                            <EditButton hideText recordItemId={row._id} />
                            <ShowButton hideText recordItemId={row._id} />
                            <DeleteButton hideText recordItemId={row._id} />
                        </>
                    );
                },
                align: "center",
                headerAlign: "center",
                minWidth: 80,
            },
        ],
        [translate],
    );

    return (
        <List>
            <DataGrid {...dataGridProps} 

                    columns={columns} 
                    autoHeight 
                    density="compact"
                    rows={data_grid.data ? data_grid.data : {}}
                    rowCount={data_grid.count}
                    //onColumnSortChange={alert("dert")}

                    checkboxSelection
                    disableSelectionOnClick
                    pageSize={pageSize}
                    onPageSizeChange={onPageSizeChange}
                    onPageChange={onPageChange}
                    rowsPerPageOptions={[10, 15, 20, 50, 100]}
                    components={{Toolbar: GridToolbar, Pagination: CustomPagination}}
                />
        </List>
    );
};
